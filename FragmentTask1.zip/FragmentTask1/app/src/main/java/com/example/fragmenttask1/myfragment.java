package com.example.fragmenttask1;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class myfragment extends Fragment {
    private int mRadioButtonChoice = 0;
    private static final String CHOICE = "choice";
    OnFragmentInteractionListener mListener;

    public myfragment() {
        // Required empty public constructor
    }

    interface OnFragmentInteractionListener {
        void onRadioButtonChoice(int choice);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new ClassCastException(context.toString()
                    + getResources().getString(R.string.exception_message));
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View rootView= inflater.inflate(R.layout.fragment_myfragment, container, false);
        final RadioGroup radioGroup=rootView.findViewById(R.id.avengerlist);

        if (getArguments().containsKey(CHOICE)) {
            // A choice was made, so get the choice.
            mRadioButtonChoice = getArguments().getInt(CHOICE);
            // Check the radio button choice.
            if (mRadioButtonChoice != 0) {
                radioGroup.check
                        (radioGroup.getChildAt(mRadioButtonChoice).getId());
                TextView textView=rootView.findViewById(R.id.answer);
                switch(mRadioButtonChoice)
                {
                    case 0:
                        textView.setText("THOR");
                        break;
                    case 1:
                        textView.setText("CAPTAIN AMERICA");
                        break;
                    case 2:
                        textView.setText("CAPTAIN MARVEL");
                        break;
                    case 3:
                        textView.setText("IRONMAN");
                        break;
                    case 4:
                        textView.setText("HULK");
                        break;
                    case 5:
                        textView.setText("WANDA");
                        break;
                }
            }
        }

        radioGroup.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int i) {
                        View  radioButton=radioGroup.findViewById(i);
                        int index=radioGroup.indexOfChild(radioButton);
                        TextView textView=rootView.findViewById(R.id.answer);
                        switch(index)
                        {
                            case 0:
                                textView.setText("THOR");
                                mRadioButtonChoice = 0;
                                mListener.onRadioButtonChoice(0);
                                break;
                            case 1:
                                textView.setText("CAPTAIN AMERICA");
                                mRadioButtonChoice = 1;
                                mListener.onRadioButtonChoice(1);
                                break;
                            case 2:
                                textView.setText("CAPTAIN MARVEL");
                                mRadioButtonChoice = 2;
                                mListener.onRadioButtonChoice(2);
                                break;
                            case 3:
                                textView.setText("IRONMAN");
                                mRadioButtonChoice = 3;
                                mListener.onRadioButtonChoice(3);
                                break;
                            case 4:
                                textView.setText("HULK");
                                mRadioButtonChoice = 4;
                                mListener.onRadioButtonChoice(4);
                                break;
                            case 5:
                                textView.setText("WANDA");
                                mRadioButtonChoice = 5;
                                mListener.onRadioButtonChoice(5);
                                break;
                        }
                    }
                }
        );
        return rootView;
    }
    public static myfragment newInstance(int choice) {
        myfragment fragment = new myfragment();
        Bundle arguments = new Bundle();
        arguments.putInt(CHOICE, choice);
        fragment.setArguments(arguments);
        return fragment;
    }

}
